#include <stdio.h>
#include <string.h>
#include <locale.h>

const char caminho[] = "arquivo.txt";

void registrar() {
    FILE* arquivo = fopen(caminho, "a+");
		char usuario [256];
		char secret [256];

    printf("Digite o usuario: ");
    scanf("%s", usuario);

    while (!feof(arquivo)) {
        char user [256];
        char escondido [256];

        fscanf (arquivo, " %s %s", user, escondido);
				if (strcmp(user, usuario) == 0) {
				    printf ("Impossivel registrar, login já existente palhaço\n");
        		fclose(arquivo);
            return;
				}
    }

		printf("digite sua senha: ");
    scanf("%s", secret);

    fprintf(arquivo, "%s %s\n", usuario, secret);
    fclose(arquivo);
}

void login() {
    char logusu[256] = "";
    char senha[256] = "";

    FILE* arquivo = fopen(caminho, "r");

    printf("digite o usuario: ");
    scanf("%s", logusu);

		while (!feof(arquivo)) {
				char nome [256];
				char segredo [256];

				fscanf (arquivo, " %s %s", nome, segredo);
				if (strcmp(logusu, nome) == 0) {
				    printf ("digite a senha");
				    scanf ("%s", senha);

				    if (strcmp(senha, segredo) == 0) {
		            printf ("Seja Bem Vinde\n");
				    } else {
				        printf ("Senha Incorreta\n");
				    }

				    fclose(arquivo);
				    return;
				}
		}
		
		printf ("login não encontrado\n");
		fclose(arquivo);
}

int main() {
    setlocale(LC_ALL, "portuguese");
    int opcao;

    printf("digite a sua opção\n");
    printf("1. registrar-se\n");
    printf("2. login\n");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1: { // registrar]
            registrar();
            break;
        }
        case 2: {
            login();
            break;
        }
        default: {
            break;
        }
    }

    return 0;
}
